/*
 * Elusive Cursor - Win32 Prank Application
 * ==========================================
 * Makes the mouse cursor "jump away" when the user
 * tries to click near the Start button (bottom-left),
 * and jitters the mouse every few seconds.
 *
 * SECRET KILL SWITCH: Press Ctrl + F12 to exit the program.
 *
 * Build with:
 *   gcc elusive_cursor.c -o elusive_cursor.exe -lgdi32 -luser32
 * Or in CodeBlocks: Add user32 to linker libraries.
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* -----------------------------------------------
   CONFIGURATION - tweak these values
   ----------------------------------------------- */

/* How close (in pixels) the cursor can get to the
   Start button zone before we "push" it away       */
#define START_ZONE_SIZE     80

/* How many pixels to jump when fleeing             */
#define JUMP_DISTANCE       120

/* Timer interval in milliseconds (3 seconds)       */
#define JITTER_INTERVAL_MS  3000

/* Small random jitter range in pixels              */
#define JITTER_RANGE        40

/* Timer ID (arbitrary number, just an identifier)  */
#define TIMER_ID            1

/* Hotkey ID for kill switch                        */
#define HOTKEY_ID           2

/* -----------------------------------------------
   GLOBAL STATE
   ----------------------------------------------- */
int screen_width  = 0;
int screen_height = 0;
BOOL program_running = TRUE;

/* -----------------------------------------------
   HELPER: Clamp a value between min and max
   ----------------------------------------------- */
int clamp(int value, int min_val, int max_val) {
    if (value < min_val) return min_val;
    if (value > max_val) return max_val;
    return value;
}

/* -----------------------------------------------
   HELPER: Check if cursor is near the Start button
   Windows Start button is at bottom-left corner.
   ----------------------------------------------- */
BOOL near_start_button(int x, int y) {
    /* Start button zone: bottom-left corner */
    return (x < START_ZONE_SIZE &&
            y > (screen_height - START_ZONE_SIZE));
}

/* -----------------------------------------------
   ACTION: Jump the cursor away from current pos
   ----------------------------------------------- */
void jump_cursor_away(int cur_x, int cur_y) {
    /* Jump to the right and upward from current pos */
    int new_x = cur_x + JUMP_DISTANCE;
    int new_y = cur_y - JUMP_DISTANCE;

    /* Keep within screen bounds using GetSystemMetrics */
    new_x = clamp(new_x, 0, screen_width  - 1);
    new_y = clamp(new_y, 0, screen_height - 1);

    SetCursorPos(new_x, new_y);
}

/* -----------------------------------------------
   ACTION: Randomly jitter the cursor slightly
   ----------------------------------------------- */
void jitter_cursor(void) {
    POINT pt;
    GetCursorPos(&pt);

    /* Random offset between -JITTER_RANGE/2 and +JITTER_RANGE/2 */
    int offset_x = (rand() % JITTER_RANGE) - (JITTER_RANGE / 2);
    int offset_y = (rand() % JITTER_RANGE) - (JITTER_RANGE / 2);

    int new_x = clamp((int)pt.x + offset_x, 0, screen_width  - 1);
    int new_y = clamp((int)pt.y + offset_y, 0, screen_height - 1);

    SetCursorPos(new_x, new_y);
}

/* -----------------------------------------------
   WINDOW PROCEDURE
   Handles timer ticks, hotkey, and messages.
   ----------------------------------------------- */
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg,
                          WPARAM wParam, LPARAM lParam)
{
    switch (msg) {

        case WM_TIMER: {
            if (wParam == TIMER_ID) {
                POINT pt;
                GetCursorPos(&pt);

                if (near_start_button((int)pt.x, (int)pt.y)) {
                    /* Cursor is near Start button - push it away! */
                    jump_cursor_away((int)pt.x, (int)pt.y);
                } else {
                    /* Otherwise, just do a random jitter */
                    jitter_cursor();
                }
            }
            break;
        }

        case WM_HOTKEY: {
            if (wParam == HOTKEY_ID) {
                /* Secret kill switch: Ctrl + F12 pressed */
                MessageBox(hwnd,
                    "Elusive Cursor stopped!\nYou found the kill switch.",
                    "Goodbye!", MB_OK | MB_ICONINFORMATION);
                program_running = FALSE;
                PostQuitMessage(0);
            }
            break;
        }

        case WM_DESTROY: {
            PostQuitMessage(0);
            break;
        }

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

/* -----------------------------------------------
   MAIN ENTRY POINT (Win32 uses WinMain)
   ----------------------------------------------- */
int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR     lpCmdLine,
                   int       nCmdShow)
{
    srand((unsigned int)time(NULL));

    /* Step 1: Get screen dimensions using GetSystemMetrics */
    screen_width  = GetSystemMetrics(SM_CXSCREEN);
    screen_height = GetSystemMetrics(SM_CYSCREEN);

    /* Step 2: Register a minimal window class (needed for message loop) */
    WNDCLASS wc = {0};
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.lpszClassName = "ElusiveCursorClass";

    if (!RegisterClass(&wc)) {
        MessageBox(NULL, "Failed to register window class!",
                   "Error", MB_OK | MB_ICONERROR);
        return 1;
    }

    /* Step 3: Create a hidden window (we don't need a visible UI) */
    HWND hwnd = CreateWindowEx(
        0,
        "ElusiveCursorClass",
        "Elusive Cursor",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT,
        NULL, NULL, hInstance, NULL
    );

    if (!hwnd) {
        MessageBox(NULL, "Failed to create window!",
                   "Error", MB_OK | MB_ICONERROR);
        return 1;
    }

    /* Window is hidden - this is a background app */
    /* ShowWindow(hwnd, SW_HIDE); */

    /* Step 4: Register kill switch hotkey: Ctrl + F12 */
    if (!RegisterHotKey(hwnd, HOTKEY_ID, MOD_CONTROL, VK_F12)) {
        MessageBox(hwnd,
            "Could not register hotkey Ctrl+F12.\n"
            "Another app may be using it.",
            "Warning", MB_OK | MB_ICONWARNING);
    }

    /* Step 5: Set a repeating timer */
    SetTimer(hwnd, TIMER_ID, JITTER_INTERVAL_MS, NULL);

    /* Notify user how to stop it */
    MessageBox(hwnd,
        "Elusive Cursor is now ACTIVE!\n\n"
        "- Mouse will jitter every 3 seconds\n"
        "- Cursor will flee from the Start button\n\n"
        "Press Ctrl + F12 to stop.",
        "Elusive Cursor Started", MB_OK | MB_ICONWARNING);

    /* Step 6: Standard Win32 message loop */
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    /* Cleanup */
    KillTimer(hwnd, TIMER_ID);
    UnregisterHotKey(hwnd, HOTKEY_ID);

    return 0;
}
