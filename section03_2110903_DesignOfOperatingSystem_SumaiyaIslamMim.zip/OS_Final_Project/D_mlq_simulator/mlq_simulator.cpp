/*
 * Time-Sliced Multilevel Queue (MLQ) Simulator
 * ==============================================
 * Queue 1 (System,      priority 0-10):  50% CPU -> Round Robin (quantum=2)
 * Queue 2 (Interactive, priority 11-20): 30% CPU -> Shortest Job First (SJF)
 * Queue 3 (Batch,       priority 21-30): 20% CPU -> First-Come First-Served
 *
 * Global time slice = 10 units:
 *   Q1 gets 5 units, Q2 gets 3 units, Q3 gets 2 units, then repeat.
 *
 * Build:
 *   g++ mlq_simulator.cpp -o mlq_simulator
 * Run:
 *   ./mlq_simulator
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <string>
#include <climits>

using namespace std;

/* -----------------------------------------------
   PROCESS STRUCTURE
   ----------------------------------------------- */
struct Process {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int priority;        // 0-10=Q1, 11-20=Q2, 21-30=Q3

    // Metrics (filled during simulation)
    int completion_time = 0;
    int first_run_time  = -1;  // for response time
    bool started        = false;
    bool finished       = false;
};

/* -----------------------------------------------
   GANTT CHART ENTRY
   ----------------------------------------------- */
struct GanttEntry {
    int pid;        // -1 = idle
    int start;
    int end;
    int queue_num;
};

/* -----------------------------------------------
   GLOBALS
   ----------------------------------------------- */
vector<Process> Q1, Q2, Q3;
vector<GanttEntry> gantt;

int global_time = 0;

/* Allocation per cycle (total slice = 10) */
const int SLICE_Q1 = 5;
const int SLICE_Q2 = 3;
const int SLICE_Q3 = 2;
const int RR_QUANTUM = 2;  // Round Robin quantum for Q1

/* -----------------------------------------------
   HELPER: Assign process to correct queue
   based on priority range
   ----------------------------------------------- */
void assign_to_queue(Process &p) {
    if      (p.priority <= 10) Q1.push_back(p);
    else if (p.priority <= 20) Q2.push_back(p);
    else                       Q3.push_back(p);
}

/* -----------------------------------------------
   HELPER: Check if any work remains
   ----------------------------------------------- */
bool all_done(const vector<Process> &q) {
    for (auto &p : q)
        if (!p.finished) return false;
    return true;
}

bool simulation_done() {
    return all_done(Q1) && all_done(Q2) && all_done(Q3);
}

/* -----------------------------------------------
   HELPER: Admit newly arrived processes
   into queues at the current global_time
   (processes arrive during simulation)
   ----------------------------------------------- */
// (In this simulator all processes are pre-loaded,
//  but arrival_time is respected: a process only
//  runs if global_time >= its arrival_time)

/* -----------------------------------------------
   EXECUTE Q1: Round Robin
   Run for up to 'time_budget' units.
   Cycles through Q1 processes with quantum=RR_QUANTUM.
   ----------------------------------------------- */
void run_Q1(int time_budget) {
    int budget_left = time_budget;
    int rr_idx = 0;

    // Keep cycling until budget exhausted or Q1 all done
    int passes = 0;
    int total_active = 0;
    for (auto &p : Q1) if (!p.finished) total_active++;
    if (total_active == 0) {
        global_time += time_budget;
        gantt.push_back({-1, global_time - time_budget, global_time, 1});
        return;
    }

    while (budget_left > 0) {
        bool any_ran = false;
        for (int i = 0; i < (int)Q1.size() && budget_left > 0; i++) {
            Process &p = Q1[i];
            if (p.finished) continue;
            if (global_time < p.arrival_time) continue;

            // Record first run
            if (!p.started) {
                p.first_run_time = global_time;
                p.started = true;
            }

            int run = min({RR_QUANTUM, p.remaining_time, budget_left});
            gantt.push_back({p.pid, global_time, global_time + run, 1});
            global_time      += run;
            budget_left      -= run;
            p.remaining_time -= run;
            any_ran = true;

            if (p.remaining_time == 0) {
                p.finished        = true;
                p.completion_time = global_time;
            }
        }
        if (!any_ran) {
            // No process ready - advance time
            global_time++;
            budget_left--;
        }
        // Safety: if all Q1 done, stop
        if (all_done(Q1)) {
            // Remaining budget is wasted (or could go to next queue,
            // but strict time-slice means we still wait)
            if (budget_left > 0) {
                gantt.push_back({-1, global_time, global_time + budget_left, 1});
                global_time += budget_left;
            }
            break;
        }
    }
}

/* -----------------------------------------------
   EXECUTE Q2: Shortest Job First (SJF)
   Sort by remaining_time, run shortest first.
   Run for up to 'time_budget' units.
   ----------------------------------------------- */
void run_Q2(int time_budget) {
    int budget_left = time_budget;

    // Check if anything to run
    bool any_ready = false;
    for (auto &p : Q2)
        if (!p.finished && global_time >= p.arrival_time) { any_ready = true; break; }

    if (!any_ready) {
        gantt.push_back({-1, global_time, global_time + time_budget, 2});
        global_time += time_budget;
        return;
    }

    // Sort Q2 by remaining_time (SJF - shortest first)
    sort(Q2.begin(), Q2.end(), [](const Process &a, const Process &b) {
        if (a.finished != b.finished) return !a.finished;  // unfinished first
        return a.remaining_time < b.remaining_time;
    });

    while (budget_left > 0) {
        bool ran = false;
        for (auto &p : Q2) {
            if (p.finished) continue;
            if (global_time < p.arrival_time) continue;

            if (!p.started) {
                p.first_run_time = global_time;
                p.started = true;
            }

            // SJF runs the whole job (non-preemptive) but capped by budget
            int run = min(p.remaining_time, budget_left);
            gantt.push_back({p.pid, global_time, global_time + run, 2});
            global_time      += run;
            budget_left      -= run;
            p.remaining_time -= run;
            ran = true;

            if (p.remaining_time == 0) {
                p.finished        = true;
                p.completion_time = global_time;
            }
            break;  // Re-sort after each process (pick next shortest)
        }
        if (!ran) {
            global_time++;
            budget_left--;
        }
        if (all_done(Q2)) {
            if (budget_left > 0) {
                gantt.push_back({-1, global_time, global_time + budget_left, 2});
                global_time += budget_left;
            }
            break;
        }
        // Re-sort for next pick
        sort(Q2.begin(), Q2.end(), [](const Process &a, const Process &b) {
            if (a.finished != b.finished) return !a.finished;
            return a.remaining_time < b.remaining_time;
        });
    }
}

/* -----------------------------------------------
   EXECUTE Q3: First Come First Served (FCFS)
   Sort by arrival_time, run in order.
   Run for up to 'time_budget' units.
   ----------------------------------------------- */
void run_Q3(int time_budget) {
    int budget_left = time_budget;

    // Sort by arrival time
    sort(Q3.begin(), Q3.end(), [](const Process &a, const Process &b) {
        return a.arrival_time < b.arrival_time;
    });

    bool any_ready = false;
    for (auto &p : Q3)
        if (!p.finished && global_time >= p.arrival_time) { any_ready = true; break; }

    if (!any_ready) {
        gantt.push_back({-1, global_time, global_time + time_budget, 3});
        global_time += time_budget;
        return;
    }

    while (budget_left > 0) {
        bool ran = false;
        for (auto &p : Q3) {
            if (p.finished) continue;
            if (global_time < p.arrival_time) continue;

            if (!p.started) {
                p.first_run_time = global_time;
                p.started = true;
            }

            int run = min(p.remaining_time, budget_left);
            gantt.push_back({p.pid, global_time, global_time + run, 3});
            global_time      += run;
            budget_left      -= run;
            p.remaining_time -= run;
            ran = true;

            if (p.remaining_time == 0) {
                p.finished        = true;
                p.completion_time = global_time;
            }
            break;  // FCFS: finish one at a time
        }
        if (!ran) {
            global_time++;
            budget_left--;
        }
        if (all_done(Q3)) {
            if (budget_left > 0) {
                gantt.push_back({-1, global_time, global_time + budget_left, 3});
                global_time += budget_left;
            }
            break;
        }
    }
}

/* -----------------------------------------------
   PRINT GANTT CHART
   ----------------------------------------------- */
void print_gantt() {
    cout << "\n===== GANTT CHART =====\n";
    string bar = "";
    string times = "";
    for (auto &g : gantt) {
        string label;
        if (g.pid == -1)
            label = " IDLE";
        else
            label = " P" + to_string(g.pid) + "(Q" + to_string(g.queue_num) + ")";

        int width = max((int)label.size(), 4);
        bar   += "|" + label + string(width - label.size(), ' ');
        times += to_string(g.start) + string(width, ' ');
    }
    bar += "|";
    times += to_string(global_time);
    cout << bar   << "\n";
    cout << times << "\n";
}

/* -----------------------------------------------
   PRINT METRICS TABLE
   ----------------------------------------------- */
void print_metrics(vector<Process> &all) {
    cout << "\n===== PERFORMANCE METRICS =====\n";
    cout << left
         << setw(5)  << "PID"
         << setw(8)  << "Queue"
         << setw(10) << "Arrival"
         << setw(8)  << "Burst"
         << setw(12) << "Finish"
         << setw(12) << "Turnaround"
         << setw(10) << "Waiting"
         << setw(10) << "Response"
         << "\n";
    cout << string(75, '-') << "\n";

    double avg_tat = 0, avg_wt = 0, avg_rt = 0;
    int count = 0;

    for (auto &p : all) {
        if (!p.finished) continue;
        int tat = p.completion_time - p.arrival_time;
        int wt  = tat - p.burst_time;
        int rt  = p.first_run_time - p.arrival_time;

        string q_label;
        if      (p.priority <= 10) q_label = "Q1(RR)";
        else if (p.priority <= 20) q_label = "Q2(SJF)";
        else                       q_label = "Q3(FCFS)";

        cout << left
             << setw(5)  << p.pid
             << setw(8)  << q_label
             << setw(10) << p.arrival_time
             << setw(8)  << p.burst_time
             << setw(12) << p.completion_time
             << setw(12) << tat
             << setw(10) << wt
             << setw(10) << rt
             << "\n";

        avg_tat += tat;
        avg_wt  += wt;
        avg_rt  += rt;
        count++;
    }

    if (count > 0) {
        cout << string(75, '-') << "\n";
        cout << fixed << setprecision(2);
        cout << "Average Turnaround Time : " << avg_tat / count << "\n";
        cout << "Average Waiting Time    : " << avg_wt  / count << "\n";
        cout << "Average Response Time   : " << avg_rt  / count << "\n";
    }
}

/* -----------------------------------------------
   MAIN
   ----------------------------------------------- */
int main() {
    cout << "=== Time-Sliced Multilevel Queue Simulator ===\n\n";

    /*
     * Sample processes:
     * Priority 0-10  -> Q1 (System,      Round Robin)
     * Priority 11-20 -> Q2 (Interactive, SJF)
     * Priority 21-30 -> Q3 (Batch,       FCFS)
     */
    vector<Process> all_processes = {
    //  pid  arrival  burst  remaining  priority
        { 1,    0,      6,     6,         5  },   // Q1
        { 2,    0,      4,     4,         3  },   // Q1
        { 3,    1,      8,     8,        15  },   // Q2
        { 4,    2,      3,     3,        12  },   // Q2
        { 5,    0,     10,    10,        25  },   // Q3
        { 6,    3,      5,     5,        22  },   // Q3
        { 7,    1,      2,     2,         8  },   // Q1
        { 8,    2,      7,     7,        18  },   // Q2
    };

    // Assign processes to queues
    for (auto &p : all_processes)
        assign_to_queue(p);

    cout << "Processes loaded:\n";
    cout << left << setw(5) << "PID" << setw(10) << "Arrival"
         << setw(8) << "Burst" << setw(10) << "Priority" << "Queue\n";
    cout << string(40, '-') << "\n";
    for (auto &p : all_processes) {
        string q = (p.priority <= 10) ? "Q1-System" :
                   (p.priority <= 20) ? "Q2-Interactive" : "Q3-Batch";
        cout << left << setw(5) << p.pid << setw(10) << p.arrival_time
             << setw(8) << p.burst_time << setw(10) << p.priority << q << "\n";
    }

    cout << "\nTime slice config: Q1=" << SLICE_Q1
         << "u (RR q=" << RR_QUANTUM << "), Q2="
         << SLICE_Q2 << "u (SJF), Q3=" << SLICE_Q3 << "u (FCFS)\n";
    cout << "\nStarting simulation...\n";

    // Main simulation loop
    int cycle = 0;
    while (!simulation_done()) {
        cycle++;
        cout << "\n[Cycle " << cycle << " | Time=" << global_time << "]\n";

        cout << "  -> Q1 (RR, " << SLICE_Q1 << " units)\n";
        run_Q1(SLICE_Q1);

        if (simulation_done()) break;

        cout << "  -> Q2 (SJF, " << SLICE_Q2 << " units)\n";
        run_Q2(SLICE_Q2);

        if (simulation_done()) break;

        cout << "  -> Q3 (FCFS, " << SLICE_Q3 << " units)\n";
        run_Q3(SLICE_Q3);

        if (cycle > 200) { cout << "Safety limit reached.\n"; break; }
    }

    cout << "\nSimulation complete at time = " << global_time << "\n";

    // Merge all queues back for metrics display
    vector<Process> all_finished;
    for (auto &p : Q1) all_finished.push_back(p);
    for (auto &p : Q2) all_finished.push_back(p);
    for (auto &p : Q3) all_finished.push_back(p);
    // Sort by PID for clean output
    sort(all_finished.begin(), all_finished.end(),
         [](const Process &a, const Process &b){ return a.pid < b.pid; });

    print_gantt();
    print_metrics(all_finished);

    return 0;
}
