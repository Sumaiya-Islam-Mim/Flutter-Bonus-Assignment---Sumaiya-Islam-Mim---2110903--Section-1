/*
 * Real-Time Task Scheduler & Schedulability Analyzer
 * ====================================================
 * Supports: Rate Monotonic (RM) + Earliest Deadline First (EDF)
 *
 * Test Case (from assignment):
 *   T1: Ci=2, Ti=5,  Ui=0.40
 *   T2: Ci=4, Ti=10, Ui=0.40
 *   T3: Ci=1, Ti=20, Ui=0.05
 *   Total U = 0.85
 *
 * Build: g++ rt_scheduler_final.cpp -o rt_scheduler_final
 * Run:   ./rt_scheduler_final
 */

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;

/* -----------------------------------------------
   TASK STRUCTURE
   ----------------------------------------------- */
struct Task {
    int    id;
    string name;
    int    execution_time;   // Ci
    int    period;           // Ti
    double utilization;      // Ci / Ti

    // Runtime state
    bool ready;
    int  remaining_time;
    int  absolute_deadline;
    int  rm_priority;        // 1 = highest
    int  deadline_misses;
    int  completions;
};

/* -----------------------------------------------
   GCD / LCM for hyper-period
   ----------------------------------------------- */
int gcd(int a, int b) {
    return b == 0 ? a : gcd(b, a % b);
}
int lcm(int a, int b) {
    return (a / gcd(a, b)) * b;
}
int hyper_period(vector<Task>& tasks) {
    int h = 1;
    for (auto& t : tasks) h = lcm(h, t.period);
    return h;
}

/* -----------------------------------------------
   ASSIGN RM PRIORITIES
   Shorter period = higher priority (= smaller number)
   ----------------------------------------------- */
void assign_rm_priorities(vector<Task>& tasks) {
    vector<Task*> sorted;
    for (auto& t : tasks) sorted.push_back(&t);
    sort(sorted.begin(), sorted.end(),
         [](Task* a, Task* b){ return a->period < b->period; });
    for (int i = 0; i < (int)sorted.size(); i++)
        sorted[i]->rm_priority = i + 1;
}

/* -----------------------------------------------
   RESET state before each simulation
   ----------------------------------------------- */
void reset(vector<Task>& tasks) {
    for (auto& t : tasks) {
        t.ready             = false;
        t.remaining_time    = 0;
        t.absolute_deadline = 0;
        t.deadline_misses   = 0;
        t.completions       = 0;
    }
}

/* -----------------------------------------------
   SELECT FUNCTIONS (from pseudocode)
   ----------------------------------------------- */
Task* select_earliest_deadline(vector<Task>& tasks) {
    Task* best = nullptr;
    for (auto& t : tasks) {
        if (!t.ready || t.remaining_time <= 0) continue;
        if (!best || t.absolute_deadline < best->absolute_deadline)
            best = &t;
    }
    return best;
}

Task* select_highest_static_priority(vector<Task>& tasks) {
    Task* best = nullptr;
    for (auto& t : tasks) {
        if (!t.ready || t.remaining_time <= 0) continue;
        if (!best || t.rm_priority < best->rm_priority)
            best = &t;
    }
    return best;
}

/* -----------------------------------------------
   SCHEDULABILITY ANALYSIS
   ----------------------------------------------- */
void schedulability_analysis(vector<Task>& tasks) {
    int n = tasks.size();
    double U = 0;
    for (auto& t : tasks) U += t.utilization;

    double rm_bound = n * (pow(2.0, 1.0/n) - 1.0);

    cout << "\n========================================\n";
    cout << "       SCHEDULABILITY ANALYSIS\n";
    cout << "========================================\n";
    cout << fixed << setprecision(4);
    cout << "Total Utilization U  = " << U << " (" << U*100 << "%)\n";
    cout << "RM  Bound (n=3)      = " << rm_bound << " (" << rm_bound*100 << "%)\n";
    cout << "EDF Bound            = 1.0000 (100%)\n\n";

    cout << left << setw(6) << "Task"
                 << setw(10) << "Ci"
                 << setw(10) << "Ti"
                 << "Ui\n";
    cout << string(30, '-') << "\n";
    for (auto& t : tasks)
        cout << setw(6)  << t.name
             << setw(10) << t.execution_time
             << setw(10) << t.period
             << setprecision(2) << t.utilization << "\n";
    cout << string(30, '-') << "\n";
    cout << setw(16) << "Total U:" << setprecision(2) << U << "\n\n";

    if (U > 1.0)
        cout << "[!!] OVERLOADED: Neither RM nor EDF can schedule!\n";
    else if (U > rm_bound) {
        cout << "[RM ] INCONCLUSIVE: U=" << setprecision(3) << U
             << " > RM bound=" << rm_bound << "\n";
        cout << "      Simulation will determine actual result.\n";
        cout << "[EDF] GUARANTEED feasible (U < 1.0)\n";
    } else {
        cout << "[RM ] GUARANTEED feasible\n";
        cout << "[EDF] GUARANTEED feasible\n";
    }
}

/* -----------------------------------------------
   GANTT CHART (simple text)
   ----------------------------------------------- */
void print_gantt(vector<pair<string,int>>& log, int end_time) {
    cout << "\n  Gantt Chart:\n  ";
    string prev = "";
    int start = 0;
    // Merge same consecutive
    vector<pair<string,pair<int,int>>> merged;
    for (int i = 0; i < (int)log.size(); i++) {
        if (merged.empty() || merged.back().first != log[i].first) {
            merged.push_back({log[i].first, {log[i].second, log[i].second+1}});
        } else {
            merged.back().second.second = log[i].second + 1;
        }
    }
    for (auto& m : merged) {
        string lbl = m.first;
        int w = max(5, (int)lbl.size() + 2);
        cout << "|" << lbl << string(w - lbl.size(), '-');
    }
    cout << "|\n  ";
    for (auto& m : merged) {
        string ts = to_string(m.second.first);
        int w = max(5, (int)m.first.size() + 2) + 1;
        cout << ts << string(w - ts.size(), ' ');
    }
    cout << end_time << "\n";
}

/* -----------------------------------------------
   CORE SIMULATION LOOP
   (exact pseudocode structure from assignment)
   ----------------------------------------------- */
void simulate(vector<Task> tasks, int sim_time, string mode) {
    cout << "\n\n========================================\n";
    cout << "  SIMULATION: " << mode << " (0 to " << sim_time << ")\n";
    cout << "========================================\n";

    assign_rm_priorities(tasks);
    reset(tasks);

    vector<pair<string,int>> gantt_log; // <name, time>

    /* ============================================
       PSEUDOCODE LOOP (verbatim from assignment)
       ============================================ */
    int current_time = 0;

    while (current_time < sim_time) {

        // 1. Activate tasks whose periods have started
        for (auto& task : tasks) {
            if (current_time % task.period == 0) {
                if (task.ready && task.remaining_time > 0) {
                    cout << "  [MISS] " << task.name
                         << " missed deadline at t=" << current_time << "\n";
                    task.deadline_misses++;
                }
                task.ready             = true;
                task.remaining_time    = task.execution_time;
                task.absolute_deadline = current_time + task.period;
            }
        }

        // 2. Select task based on mode (RM vs EDF)
        Task* best_task = nullptr;
        if (mode == "EDF")
            best_task = select_earliest_deadline(tasks);
        else
            best_task = select_highest_static_priority(tasks);

        // 3. Execute and check for deadline misses
        if (best_task) {
            gantt_log.push_back({best_task->name, current_time});
            best_task->remaining_time--;

            if (current_time + 1 > best_task->absolute_deadline) {
                cout << "  [MISS] Deadline Missed for "
                     << best_task->name
                     << " at t=" << current_time + 1 << "\n";
                best_task->deadline_misses++;
            }
            if (best_task->remaining_time == 0) {
                best_task->ready = false;
                best_task->completions++;
            }
        } else {
            gantt_log.push_back({"IDLE", current_time});
        }

        current_time++;
    }
    /* ============================================ */

    print_gantt(gantt_log, sim_time);

    // Results table
    cout << "\n  Results:\n";
    cout << "  " << left << setw(8) << "Task"
                         << setw(12) << "Instances"
                         << setw(12) << "Completed"
                         << "Misses\n";
    cout << "  " << string(44, '-') << "\n";
    int total_miss = 0;
    for (auto& t : tasks) {
        int inst = sim_time / t.period;
        total_miss += t.deadline_misses;
        cout << "  " << setw(8)  << t.name
                     << setw(12) << inst
                     << setw(12) << t.completions
                     << t.deadline_misses << "\n";
    }
    cout << "  " << string(44, '-') << "\n";
    if (total_miss == 0)
        cout << "  [PASS] All deadlines met!\n";
    else
        cout << "  [FAIL] " << total_miss << " deadline miss(es)!\n";
}

/* -----------------------------------------------
   MAIN
   ----------------------------------------------- */
int main() {
    cout << "=== Real-Time Task Scheduler ===\n";

    // Assignment test case
    vector<Task> tasks = {
        {0, "T1", 2,  5, 0.40, false, 0, 0, 0, 0, 0},
        {1, "T2", 4, 10, 0.40, false, 0, 0, 0, 0, 0},
        {2, "T3", 1, 20, 0.05, false, 0, 0, 0, 0, 0},
    };

    int hp = hyper_period(tasks); // LCM(5,10,20) = 20
    cout << "\nTask Set | Hyper-period = LCM(5,10,20) = " << hp << "\n";

    // Step 1: Schedulability check
    schedulability_analysis(tasks);

    // Step 2: Run RM
    simulate(tasks, hp, "RM");

    // Step 3: Run EDF
    simulate(tasks, hp, "EDF");

    cout << "\n\n========================================\n";
    cout << "  SUMMARY\n";
    cout << "========================================\n";
    cout << "  U=0.85 | RM bound=0.779 | EDF bound=1.0\n";
    cout << "  RM : Inconclusive -> check simulation above\n";
    cout << "  EDF: Guaranteed   -> 0 misses confirmed\n";

    return 0;
}
