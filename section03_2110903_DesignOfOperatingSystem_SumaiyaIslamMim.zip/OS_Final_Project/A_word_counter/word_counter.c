#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int count_words(FILE *fp) {
    int count = 0;
    char word[1024];
    while (fscanf(fp, "%s", word) == 1) {
        count++;
    }
    return count;
}

int main() {
    /* Create test files automatically (for online compiler) */
    FILE *f;

    f = fopen("file1.txt", "w");
    fprintf(f, "Hello world this is file one with six words");
    fclose(f);

    f = fopen("file2.txt", "w");
    fprintf(f, "Bangladesh is a beautiful country with many rivers");
    fclose(f);

    f = fopen("file3.txt", "w");
    fprintf(f, "Operating systems are fun to learn and understand");
    fclose(f);

    /* File names */
    char *filenames[] = {"file1.txt", "file2.txt", "file3.txt"};
    int num_files = 3;

    printf("=== Word Counter (Fork + Pipe) ===\n");
    printf("Files: file1.txt, file2.txt, file3.txt\n\n");

    /* Create one pipe per file */
    int pipes[3][2];
    for (int i = 0; i < num_files; i++) {
        if (pipe(pipes[i]) == -1) {
            perror("pipe failed");
            return 1;
        }
    }

    /* Fork one child per file */
    for (int i = 0; i < num_files; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork failed");
            return 1;
        }

        if (pid == 0) {
            /* CHILD PROCESS */
            for (int j = 0; j < num_files; j++) close(pipes[j][0]);
            for (int j = 0; j < num_files; j++)
                if (j != i) close(pipes[j][1]);

            int result;
            FILE *fp = fopen(filenames[i], "r");

            if (fp == NULL) {
                fprintf(stderr, "Error: Cannot open '%s'\n", filenames[i]);
                result = -1;
            } else {
                result = count_words(fp);
                fclose(fp);
                printf("Child %d: '%s' has %d words\n",
                       getpid(), filenames[i], result);
            }

            write(pipes[i][1], &result, sizeof(int));
            close(pipes[i][1]);
            exit(0);
        }
    }

    /* PARENT PROCESS */
    for (int i = 0; i < num_files; i++) close(pipes[i][1]);

    int total = 0;
    for (int i = 0; i < num_files; i++) {
        int result;
        read(pipes[i][0], &result, sizeof(int));
        close(pipes[i][0]);

        if (result == -1)
            printf("Parent: Skipping '%s' (file not found)\n", filenames[i]);
        else {
            printf("Parent: Got %d words from '%s'\n", result, filenames[i]);
            total += result;
        }
    }

    for (int i = 0; i < num_files; i++) wait(NULL);

    printf("\n=== Total word count: %d ===\n", total);
    return 0;
}